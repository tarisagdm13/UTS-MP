import 'package:flutter/material.dart';
import 'home.dart';
import 'package:provider/provider.dart';
import 'models/models.dart';
import 'lamptour_theme.dart';

void main() {
  runApp(const Lamptour());
}

class Lamptour extends StatelessWidget {
  const Lamptour({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final theme = LamptourTheme.dark();
    return MaterialApp(
      theme: theme,
      title: 'Lamptour',
      home: MultiProvider(providers: [
        ChangeNotifierProvider(
          create: (context) => TabManager(),
        ),
        ChangeNotifierProvider(
          create: (context) => GroceryManager(),
        ),
      ], child: Home()),
    );
  }
}
